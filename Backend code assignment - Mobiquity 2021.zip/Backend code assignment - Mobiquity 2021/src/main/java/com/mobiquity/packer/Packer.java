package com.mobiquity.packer;

import com.mobiquity.exception.APIException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;



public class Packer
{
  double maxWeight;
  ArrayList<Item> items =new ArrayList<Item>();
  ArrayList<ArrayList<Item>> combinations =new ArrayList<>();


  private Packer(double maxWeight, ArrayList<Item> items) {
    this.maxWeight = maxWeight;
    this.items = items;
    this.combinations = combinations;
  }

  private Packer() {
  }
  public static class Item
  {
    int id;
    double weight;
    double price;

    public Item(int id, double weight, double price) {
      this.id = id;
      this.weight = weight;
      this.price = price;
    }

    @Override
    public String toString() {
      return "Item{" +
              "id=" + id +
              ", weight=" + weight +
              ", price=" + price +
              '}';
    }

  }

  public static String pack(String filePath) throws APIException, IOException
  {
      FileReader fr =new FileReader(filePath);
      BufferedReader br=new BufferedReader(fr);
      String line;
      StringBuilder sb = new StringBuilder();
      String str =null;
      while((line = br.readLine()) != null)
    {
      if(line.length() == 0)
        continue;
      String[] splitLine = line.split(":");
      double maxWeight = Integer.parseInt(splitLine[0].trim());
      String[] stringItems = splitLine[1].trim().split(" ");
      ArrayList<Item> individualItems = new ArrayList<Item>();

      for(String stringItem : stringItems)
      {
        String[] itemDetails = stringItem.split(",");
        int individualId = Integer.parseInt(itemDetails[0].substring(1));
        double individualWeight = Double.parseDouble(itemDetails[1]);
        double individualPrice = Double.parseDouble(itemDetails[2].substring(1, itemDetails[2].length()-1));
        Item item = new Item(individualId, individualWeight, individualPrice);
        individualItems.add(item);
      }
      Packer packer = new Packer(maxWeight, individualItems);
        str =packer.findPackage();
        sb.append(System.lineSeparator() +str.toString());

    }
    //System.out.println(sb.toString());
      return sb.toString();

  }


  private  String findPackage() {
    removeItems();
    combinations = allCombinations();
    if(combinations.size() == 0)
    {
      String str ="-";
      return str;
    }
    else
      {
        ArrayList<Item> finalPackage = getfinalPackage();
        String str =printOutput(finalPackage);

        return str;
      
    }
  }

  private String printOutput(ArrayList<Item> items)
  {
    StringBuilder sb = new StringBuilder();
    boolean isFirst = true;
    for (Item i : items)
    {
      if(isFirst)
      {
        sb.append(i.id);
        isFirst = false;
      }
      else
        {
        sb.append("," + i.id);
      }
    }

    return sb.toString();
  }

  private ArrayList<Item> getfinalPackage() {
    {
      ArrayList<Item> bestCombination = new ArrayList<Item>();
      double bestCost = 0;
      double bestWeight = 100; //max weight is 100
      for(ArrayList<Item> combination : combinations){
        double combinationWeight = getWeight(combination);
        if(combinationWeight > maxWeight)
        {
          continue;
        }
        else
          {
            double combinationPrice = getPrice(combination);
            if(combinationPrice > bestCost)

            {
            bestCost = combinationPrice;
            bestCombination = combination;
            bestWeight = combinationWeight;
            }
          else if(combinationPrice == bestCost)
          {
            if(combinationWeight < bestWeight){
              bestCost = combinationPrice;
              bestCombination = combination;
              bestWeight = combinationWeight;
            }
          }
        }
      }
      return bestCombination;
    }
  }

  private double getPrice(ArrayList<Item> items) {
    double total = 0;
    for(Item i : items)
    {
      total = total +i.price;
    }
    return total;
  }

  private double getWeight(ArrayList<Item> items) {
    double total = 0;
    for(Item i : items)
    {
      total = total +i.weight;
    }
    return total;
  }

  private ArrayList<ArrayList<Item>> allCombinations() {
    for(int i = 0; i < items.size(); i++)
    {
      Item currentItem = items.get(i);
      int combinationSize = combinations.size();

      for(int j = 0; j < combinationSize; j++)
      {
        ArrayList<Item> combination = combinations.get(j);
        ArrayList<Item> newCombination = new ArrayList<Item>(combination);
        newCombination.add(currentItem);

        combinations.add(newCombination);
      }
      ArrayList<Item> current = new ArrayList<Item>();
      current.add(currentItem);

      combinations.add(current);

    }
    return combinations;
  }

  private void removeItems() {
    Iterator<Item> iter = items.iterator();
    while(iter.hasNext())
    {
      Item i = iter.next();
      if(i.weight > maxWeight)
        iter.remove();
    }
  }


//  public static void main(String args[]) throws Exception
//  {
//
//    String str1 =System.getProperty("user.dir");
//    //String actual = Files.readString(Path.of(str1));
//    String str =pack(str1+"/src/main/test/resources/example_input");
//
//    //System.out.println(actual);
//    System.out.print(str);
//  }

}
